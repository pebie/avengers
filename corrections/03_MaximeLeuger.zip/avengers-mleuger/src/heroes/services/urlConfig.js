(function() {
    'use strict';
    angular.module('avengersApp').constant('urlConfig', {'HEROES': './mocks/heroes.json'});
}());
