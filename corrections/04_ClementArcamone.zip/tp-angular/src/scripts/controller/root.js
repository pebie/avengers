angular.module("avengersApp").controller("RootCtrl",function($scope, $filter){

    $scope.title = "AngularJs Formation";

});