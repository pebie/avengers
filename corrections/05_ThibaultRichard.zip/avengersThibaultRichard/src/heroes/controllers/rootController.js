(function() {
    'use strict';

    angular
        .module('myAvengers')
        .controller('RootController', function($scope, $location) {

        });

}());
