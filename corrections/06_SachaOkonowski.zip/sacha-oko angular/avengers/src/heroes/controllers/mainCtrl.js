
(function() {
    'use strict';

    var app = angular.module('myApp');

    app.controller('MainCtrl', function($scope, $location) {



    });

}());
