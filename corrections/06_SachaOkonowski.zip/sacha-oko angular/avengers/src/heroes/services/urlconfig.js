(function() {
    'use strict';

    var app = angular.module('myApp');

    app.constant('urlConfig', {
        'HEROES': './mocks/heroes.json'
    });

}());
