// Contrôleur du détail du personnage

avengersAppControllers.controller('HeroeDetailCtrl', ['$scope',
  function($scope,heroDetail, heroesFactory, $log, $location, $routeParams){

    $scope.msg = "Détails du personnage";

  }
]);
