angular.module('avengersApp').constant('urlConfig', {
  "HEROES_LIST":"../mocks/heroes.json"
});
